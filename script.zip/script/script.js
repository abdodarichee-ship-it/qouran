// العناصر الرئيسية في DOM
const videosContainer = document.getElementById('videosContainer');
const videoPopup = document.getElementById('videoPopup');
const videoPlayer = document.getElementById('videoPlayer');
const videoTitle = document.getElementById('videoTitle');
const playlistContainer = document.getElementById('playlistContainer');
const miniPlayer = document.getElementById('miniPlayer');
const miniThumbnail = document.getElementById('miniThumbnail');
const miniTitle = document.getElementById('miniTitle');
const miniCloseArea = document.querySelector('.mini-close-area');
const searchPopup = document.getElementById('searchPopup');
const backBtn = document.getElementById('backBtn');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const loading = document.getElementById('loading');
const readingPopup = document.getElementById('readingPopup');
const readingBackBtn = document.getElementById('readingBackBtn');
const tafsirPopup = document.getElementById('tafsirPopup');
const tafsirBackBtn = document.getElementById('tafsirBackBtn');
const settingsPopup = document.getElementById('settingsPopup');
const settingsBackBtn = document.getElementById('settingsBackBtn');
const settingsBtn = document.getElementById('settingsBtn');

// عناصر القراءة
const sowarList = document.getElementById("sowarList");
const readingTitle = document.getElementById("readingTitle");
const readingText = document.getElementById("readingText");
const soraSearchInput = document.getElementById("soraSearchInput");
const soraContent = document.getElementById("soraContent");

// عناصر التفسير
const tafsirList = document.getElementById("tafsirList");
const tafsirTitle = document.getElementById("tafsirTitle");
const tafsirType = document.getElementById("tafsirType");
const tafsirText = document.getElementById("tafsirText");
const tafsirSearchInput = document.getElementById("tafsirSearchInput");
const tafsirSoraContent = document.getElementById("tafsirSoraContent");

// عناصر الإعدادات
const themeToggle = document.getElementById('themeToggle');
const fontSizeSelect = document.getElementById('fontSize');
const autoplayToggle = document.getElementById('autoplayToggle');
const clickEffectsToggle = document.getElementById('clickEffectsToggle');

// أزرار الشريط السفلي
const homeBtn = document.getElementById('homeBtn');
const searchBottomBtn = document.getElementById('searchBottomBtn');
const readingBtn = document.getElementById('readingBtn');
const tafsirBtn = document.getElementById('tafsirBtn');

// المتغيرات العامة
let videosData = [];
let allSowar = [];
let allTafsir = [];
let currentVideoId = null;
let isVideoPlaying = false;
let startX = 0;
let currentX = 0;
let isDragging = false;
let activePopup = null;
let currentSoraView = 'list'; // 'list' أو 'content'
let currentTafsirView = 'list'; // 'list' أو 'content'

// دالة لإخفاء شريط التمرير
function hideScrollbar() {
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
}

// دالة لإظهار شريط التمرير
function showScrollbar() {
    document.body.style.overflow = '';
    document.documentElement.style.overflow = '';
}

// دالة لإعادة تعيين شريط التمرير إلى الأعلى
function resetScrollPosition(element) {
    if (element) {
        element.scrollTop = 0;
    }
}

// دالة لإعادة تعيين جميع عناصر التمرير في النوافذ
function resetAllScrollPositions() {
    resetScrollPosition(document.querySelector('.reading-content'));
    resetScrollPosition(sowarList);
    resetScrollPosition(searchResults);
    resetScrollPosition(playlistContainer);
    resetScrollPosition(document.querySelector('.tafsir-content'));
    resetScrollPosition(tafsirList);
    resetScrollPosition(document.querySelector('.settings-content'));
}

// دالة لإخفاء جميع النوافذ
function hideAllPopups() {
    const popups = [videoPopup, searchPopup, readingPopup, tafsirPopup, settingsPopup];
    popups.forEach(popup => popup.classList.remove('active'));
    activePopup = null;
    resetAllScrollPositions();
    showScrollbar();
}

// دالة لتحديد حالة الأزرار في الشريط السفلي
function updateBottomBarButtons(activeButton) {
    const buttons = [homeBtn, searchBottomBtn, readingBtn, tafsirBtn];
    buttons.forEach(btn => btn.classList.remove('active'));
    if (activeButton) activeButton.classList.add('active');
}

// تحميل بيانات الفيديوهات من الملف الخارجي
async function loadVideos() {
    try {
        showLoading();
        
        const response = await fetch('/vidou/vidou.html');
        if (!response.ok) throw new Error(`فشل في تحميل البيانات: ${response.status}`);
        
        const htmlText = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        const qouranElements = doc.querySelectorAll('.qouran');
        if (qouranElements.length === 0) throw new Error('لم يتم العثور على عناصر .qouran في الملف');
        
        videosData = Array.from(qouranElements).map((element, index) => {
            const imgElement = element.querySelector('img#photo');
            const titleElement = element.querySelector('h3#name');
            const codeElement = element.querySelector('samp#code');
            
            if (!imgElement || !titleElement || !codeElement) return null;
            
            return {
                id: index + 1,
                title: titleElement.textContent.trim(),
                thumbnail: imgElement.src,
                videoCode: codeElement.textContent.trim()
            };
        }).filter(video => video !== null);
        
        if (videosData.length === 0) throw new Error('لم يتم استخراج أي فيديوهات من الملف');
        
        renderVideos();
        hideLoading();
        
    } catch (error) {
        console.error('فشل في تحميل الفيديوهات:', error);
        hideLoading();
        showError(`فشل في تحميل الفيديوهات: ${error.message}`);
    }
}

// عرض الفيديوهات في الصفحة الرئيسية
function renderVideos() {
    videosContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <div class="video-thumbnail-container">
                <img src="${video.thumbnail}" alt="${video.title}" class="video-thumbnail">
            </div>
            <div class="video-card-info">
                <h3 class="video-card-title">${video.title}</h3>
            </div>
        `;
        
        videoCard.addEventListener('click', () => openVideoPopup(video.id));
        videosContainer.appendChild(videoCard);
    });
}

// فتح نافذة الفيديو
function openVideoPopup(videoId) {
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    currentVideoId = videoId;
    const autoplay = localStorage.getItem('autoplay') === 'true' ? '1' : '0';
    videoPlayer.src = `https://www.youtube.com/embed/${video.videoCode}?autoplay=${autoplay}&enablejsapi=1`;
    videoTitle.textContent = video.title;
    miniThumbnail.src = video.thumbnail;
    miniTitle.textContent = video.title;
    
    renderPlaylist();
    hideAllPopups();
    videoPopup.classList.add('active');
    activePopup = videoPopup;
    miniPlayer.classList.remove('active');
    hideScrollbar();
    isVideoPlaying = true;
    updateBottomBarButtons(null);
    
    window.history.pushState({ 
        popupOpen: true, 
        type: 'video',
        videoId: videoId 
    }, '');
}

// عرض قائمة الفيديوهات في النافذة المنبثقة
function renderPlaylist() {
    playlistContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const playlistItem = document.createElement('div');
        playlistItem.className = `playlist-item ${video.id === currentVideoId ? 'active' : ''}`;
        playlistItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="playlist-thumbnail">
            <div class="playlist-item-info">
                <div class="playlist-title">${video.title}</div>
            </div>
        `;
        
        playlistItem.addEventListener('click', () => {
            if (video.id !== currentVideoId) openVideoPopup(video.id);
        });
        
        playlistContainer.appendChild(playlistItem);
    });
}

// إغلاق نافذة الفيديو
function closeVideoPopup() {
    videoPopup.classList.remove('active');
    activePopup = null;
    videoPlayer.src = '';
    miniPlayer.classList.remove('active');
    isVideoPlaying = false;
    resetScrollPosition(playlistContainer);
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// عرض الشريط المصغر
function showMiniPlayer() {
    videoPopup.classList.remove('active');
    activePopup = null;
    miniPlayer.classList.add('active');
    isVideoPlaying = true;
    resetScrollPosition(playlistContainer);
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// إغلاق الشريط المصغر
function closeMiniPlayer() {
    miniPlayer.classList.remove('active');
    videoPlayer.src = '';
    isVideoPlaying = false;
    showScrollbar();
    updateBottomBarButtons(homeBtn);
}

// فتح نافذة البحث
function openSearchPopup() {
    hideAllPopups();
    searchPopup.classList.add('active');
    activePopup = searchPopup;
    searchInput.focus();
    resetScrollPosition(searchResults);
    hideScrollbar();
    updateBottomBarButtons(searchBottomBtn);
    window.history.pushState({ popupOpen: true, type: 'search' }, '');
}

// إغلاق نافذة البحث
function closeSearchPopup() {
    searchPopup.classList.remove('active');
    activePopup = null;
    searchInput.value = '';
    searchResults.innerHTML = '';
    resetScrollPosition(searchResults);
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// البحث عن الفيديوهات
function searchVideos(query) {
    searchResults.innerHTML = '';
    
    if (!query.trim()) {
        searchResults.innerHTML = '<div class="no-results">اكتب كلمة للبحث</div>';
        return;
    }
    
    const filteredVideos = videosData.filter(video => 
        video.title.toLowerCase().includes(query.toLowerCase())
    );
    
    if (filteredVideos.length === 0) {
        searchResults.innerHTML = '<div class="no-results">لا توجد نتائج للبحث</div>';
        return;
    }
    
    filteredVideos.forEach(video => {
        const searchItem = document.createElement('div');
        searchItem.className = 'search-result-item';
        searchItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="search-result-thumbnail">
            <div class="search-result-info">
                <div class="search-result-title">${video.title}</div>
            </div>
        `;
        
        searchItem.addEventListener('click', () => {
            closeSearchPopup();
            setTimeout(() => openVideoPopup(video.id), 100);
        });
        
        searchResults.appendChild(searchItem);
    });
}

// تحميل السور من ملف خارجي
async function loadSowar() {
    try {
        const response = await fetch('/elkitab/elkitab.html');
        if (!response.ok) throw new Error(`فشل في تحميل السور: ${response.status}`);
        
        const htmlText = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        const soraElements = doc.querySelectorAll('.sora');
        if (soraElements.length === 0) throw new Error('لم يتم العثور على عناصر .sora في الملف');
        
        allSowar = Array.from(soraElements).map((sora, index) => {
            const nameElement = sora.querySelector('.name');
            const textElement = sora.querySelector('.text');
            
            if (!nameElement || !textElement) return null;
            
            return {
                id: index + 1,
                name: nameElement.textContent.trim(),
                text: textElement.innerHTML
            };
        }).filter(sora => sora !== null);
        
        if (allSowar.length === 0) throw new Error('لم يتم استخراج أي سور من الملف');
        
        if (readingPopup.classList.contains('active')) renderSowar(allSowar);
        
    } catch (error) {
        console.error('فشل في تحميل السور:', error);
        if (sowarList) sowarList.innerHTML = '<div class="error-message">فشل في تحميل السور</div>';
    }
}

// فتح نافذة القراءة
function openReadingPopup() {
    hideAllPopups();
    resetReadingView();
    readingPopup.classList.add('active');
    activePopup = readingPopup;
    resetScrollPosition(document.querySelector('.reading-content'));
    resetScrollPosition(sowarList);
    hideScrollbar();
    updateBottomBarButtons(readingBtn);
    
    window.history.pushState({ 
        popupOpen: true, 
        type: 'reading', 
        view: 'list' 
    }, '');
    
    if (allSowar.length === 0) loadSowar();
    else renderSowar(allSowar);
}

// إعادة تعيين عرض القراءة إلى قائمة السور
function resetReadingView() {
    currentSoraView = 'list';
    if (sowarList) sowarList.style.display = 'grid';
    if (soraContent) soraContent.classList.remove('active');
    if (soraSearchInput) soraSearchInput.value = '';
    resetScrollPosition(sowarList);
    resetScrollPosition(document.querySelector('.reading-content'));
}

// إغلاق نافذة القراءة
function closeReadingPopup() {
    readingPopup.classList.remove('active');
    activePopup = null;
    resetReadingView();
    resetScrollPosition(document.querySelector('.reading-content'));
    resetScrollPosition(sowarList);
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// العودة إلى قائمة السور من محتوى السورة
function backToSowarList() {
    currentSoraView = 'list';
    if (sowarList) sowarList.style.display = 'grid';
    if (soraContent) soraContent.classList.remove('active');
    resetScrollPosition(sowarList);
    
    if (activePopup === readingPopup) {
        window.history.replaceState({ 
            popupOpen: true, 
            type: 'reading', 
            view: 'list' 
        }, '');
    }
}

// عرض السور في القائمة
function renderSowar(sowarListData) {
    if (!sowarList) return;
    
    sowarList.innerHTML = '';
    
    sowarListData.forEach(sora => {
        const soraItem = document.createElement('div');
        soraItem.className = 'sora-item';
        soraItem.innerHTML = `<h3>${sora.name}</h3>`;
        
        soraItem.addEventListener('click', () => openSora(sora.name, sora.text));
        sowarList.appendChild(soraItem);
    });
}

// فتح سورة للقراءة
function openSora(name, text) {
    if (readingTitle) readingTitle.textContent = name;
    if (readingText) readingText.innerHTML = text;
    
    if (sowarList) sowarList.style.display = 'none';
    if (soraContent) soraContent.classList.add('active');
    currentSoraView = 'content';
    resetScrollPosition(document.querySelector('.reading-content'));
    
    if (activePopup === readingPopup) {
        window.history.pushState({ 
            popupOpen: true, 
            type: 'reading', 
            view: 'content', 
            sora: name 
        }, '');
    }
}

// البحث في السور
function searchSowar(query) {
    if (!query.trim()) {
        renderSowar(allSowar);
        return;
    }
    
    const filteredSowar = allSowar.filter(sora => 
        sora.name.toLowerCase().includes(query.toLowerCase())
    );
    renderSowar(filteredSowar);
}

// تحميل بيانات التفسير
async function loadTafsir() {
    try {
        const response = await fetch('/tafsir/tafsir.html');
        if (!response.ok) throw new Error(`فشل في تحميل التفسير: ${response.status}`);
        
        const htmlText = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        const tafsirElements = doc.querySelectorAll('.sora');
        if (tafsirElements.length === 0) throw new Error('لم يتم العثور على عناصر .sora في ملف التفسير');
        
        allTafsir = Array.from(tafsirElements).map((sora, index) => {
            const name = sora.getAttribute('data-name');
            const type = sora.getAttribute('data-type') || 'مكية';
            const tafseerElement = sora.querySelector('.tafseer');
            
            if (!name || !tafseerElement) return null;
            
            return {
                id: index + 1,
                name: name,
                type: type,
                tafseer: tafseerElement.innerHTML
            };
        }).filter(tafsir => tafsir !== null);
        
        if (allTafsir.length === 0) throw new Error('لم يتم استخراج أي تفسير من الملف');
        
        if (tafsirPopup.classList.contains('active')) renderTafsirList(allTafsir);
        
    } catch (error) {
        console.error('فشل في تحميل التفسير:', error);
        if (tafsirList) tafsirList.innerHTML = '<div class="error-message">فشل في تحميل التفسير</div>';
    }
}

// فتح نافذة التفسير
function openTafsirPopup() {
    hideAllPopups();
    resetTafsirView();
    tafsirPopup.classList.add('active');
    activePopup = tafsirPopup;
    resetScrollPosition(document.querySelector('.tafsir-content'));
    resetScrollPosition(tafsirList);
    hideScrollbar();
    updateBottomBarButtons(tafsirBtn);
    
    window.history.pushState({ 
        popupOpen: true, 
        type: 'tafsir', 
        view: 'list' 
    }, '');
    
    if (allTafsir.length === 0) loadTafsir();
    else renderTafsirList(allTafsir);
}

// إعادة تعيين عرض التفسير إلى قائمة السور
function resetTafsirView() {
    currentTafsirView = 'list';
    if (tafsirList) tafsirList.style.display = 'grid';
    if (tafsirSoraContent) tafsirSoraContent.classList.remove('active');
    if (tafsirSearchInput) tafsirSearchInput.value = '';
    resetScrollPosition(tafsirList);
    resetScrollPosition(document.querySelector('.tafsir-content'));
}

// إغلاق نافذة التفسير
function closeTafsirPopup() {
    tafsirPopup.classList.remove('active');
    activePopup = null;
    resetTafsirView();
    resetScrollPosition(document.querySelector('.tafsir-content'));
    resetScrollPosition(tafsirList);
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// العودة إلى قائمة السور من محتوى التفسير
function backToTafsirList() {
    currentTafsirView = 'list';
    if (tafsirList) tafsirList.style.display = 'grid';
    if (tafsirSoraContent) tafsirSoraContent.classList.remove('active');
    resetScrollPosition(tafsirList);
    
    if (activePopup === tafsirPopup) {
        window.history.replaceState({ 
            popupOpen: true, 
            type: 'tafsir', 
            view: 'list' 
        }, '');
    }
}

// عرض قائمة السور في التفسير
function renderTafsirList(tafsirListData) {
    if (!tafsirList) return;
    
    tafsirList.innerHTML = '';
    
    tafsirListData.forEach(tafsir => {
        const tafsirItem = document.createElement('div');
        tafsirItem.className = 'tafsir-item';
        tafsirItem.innerHTML = `<h3>${tafsir.name}</h3>`;
        
        tafsirItem.addEventListener('click', () => openTafsirSora(tafsir.name, tafsir.type, tafsir.tafseer));
        tafsirList.appendChild(tafsirItem);
    });
}

// فتح تفسير سورة محددة
function openTafsirSora(name, type, tafseer) {
    if (tafsirTitle) tafsirTitle.textContent = name;
    if (tafsirType) tafsirType.textContent = type;
    if (tafsirText) tafsirText.innerHTML = tafseer;
    
    if (tafsirList) tafsirList.style.display = 'none';
    if (tafsirSoraContent) tafsirSoraContent.classList.add('active');
    currentTafsirView = 'content';
    resetScrollPosition(document.querySelector('.tafsir-content'));
    
    if (activePopup === tafsirPopup) {
        window.history.pushState({ 
            popupOpen: true, 
            type: 'tafsir', 
            view: 'content', 
            sora: name 
        }, '');
    }
}

// البحث في التفسير
function searchTafsir(query) {
    if (!query.trim()) {
        renderTafsirList(allTafsir);
        return;
    }
    
    const filteredTafsir = allTafsir.filter(tafsir => 
        tafsir.name.toLowerCase().includes(query.toLowerCase())
    );
    renderTafsirList(filteredTafsir);
}

// فتح نافذة الإعدادات
function openSettingsPopup() {
    hideAllPopups();
    settingsPopup.classList.add('active');
    activePopup = settingsPopup;
    resetScrollPosition(document.querySelector('.settings-content'));
    hideScrollbar();
    updateBottomBarButtons(null);
    window.history.pushState({ popupOpen: true, type: 'settings' }, '');
}

// إغلاق نافذة الإعدادات
function closeSettingsPopup() {
    settingsPopup.classList.remove('active');
    activePopup = null;
    resetScrollPosition(document.querySelector('.settings-content'));
    showScrollbar();
    updateBottomBarButtons(homeBtn);
    window.history.back();
}

// العودة إلى الصفحة الرئيسية
function goToHome() {
    if (isVideoPlaying && videoPopup.classList.contains('active')) {
        showMiniPlayer();
    } else {
        hideAllPopups();
        closeMiniPlayer();
        updateBottomBarButtons(homeBtn);
        window.history.back();
    }
}

// إدارة زر الرجوع في المتصفح
function handleBackButton() {
    if (activePopup) {
        if (activePopup === searchPopup) {
            closeSearchPopup();
        } else if (activePopup === videoPopup) {
            showMiniPlayer();
        } else if (activePopup === readingPopup) {
            if (currentSoraView === 'content') backToSowarList();
            else closeReadingPopup();
        } else if (activePopup === tafsirPopup) {
            if (currentTafsirView === 'content') backToTafsirList();
            else closeTafsirPopup();
        } else if (activePopup === settingsPopup) {
            closeSettingsPopup();
        }
    } else if (miniPlayer.classList.contains('active')) {
        closeMiniPlayer();
    } else {
        updateBottomBarButtons(homeBtn);
    }
}

// التعامل مع تغيير حالة السجل التاريخي
function handlePopState(event) {
    if (event.state) {
        if (event.state.popupOpen) {
            if (event.state.type === 'reading') {
                if (event.state.view === 'list') backToSowarList();
            } else if (event.state.type === 'tafsir') {
                if (event.state.view === 'list') backToTafsirList();
            } else if (event.state.type === 'video' && event.state.videoId) {
                openVideoPopup(event.state.videoId);
            }
        } else {
            hideAllPopups();
            closeMiniPlayer();
            updateBottomBarButtons(homeBtn);
        }
    } else {
        hideAllPopups();
        closeMiniPlayer();
        updateBottomBarButtons(homeBtn);
    }
}

// تهيئة السحب لإغلاق الشريط المصغر
function initMiniPlayerDrag() {
    if (!miniPlayer) return;
    
    miniPlayer.addEventListener('touchstart', handleTouchStart);
    miniPlayer.addEventListener('touchmove', handleTouchMove);
    miniPlayer.addEventListener('touchend', handleTouchEnd);
    
    miniPlayer.addEventListener('mousedown', handleMouseStart);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseEnd);
}

function handleTouchStart(e) {
    startX = e.touches[0].clientX;
    isDragging = true;
}

function handleTouchMove(e) {
    if (!isDragging) return;
    currentX = e.touches[0].clientX;
    const diff = currentX - startX;
    if (diff > 50) miniPlayer.style.transform = `translateX(${diff}px)`;
}

function handleTouchEnd() {
    if (!isDragging) return;
    isDragging = false;
    const diff = currentX - startX;
    if (diff > 100) closeMiniPlayer();
    else miniPlayer.style.transform = 'translateX(0)';
    startX = 0; currentX = 0;
}

function handleMouseStart(e) {
    startX = e.clientX;
    isDragging = true;
    e.preventDefault();
}

function handleMouseMove(e) {
    if (!isDragging) return;
    currentX = e.clientX;
    const diff = currentX - startX;
    if (diff > 50) miniPlayer.style.transform = `translateX(${diff}px)`;
}

function handleMouseEnd() {
    if (!isDragging) return;
    isDragging = false;
    const diff = currentX - startX;
    if (diff > 100) closeMiniPlayer();
    else miniPlayer.style.transform = 'translateX(0)';
    startX = 0; currentX = 0;
}

// عرض التحميل
function showLoading() {
    if (loading) {
        loading.style.display = 'flex';
        hideScrollbar();
    }
}

// إخفاء التحميل
function hideLoading() {
    if (loading) {
        loading.style.display = 'none';
        showScrollbar();
    }
}

// عرض خطأ
function showError(message) {
    if (videosContainer) {
        videosContainer.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>${message}</p>
                <button onclick="loadVideos()" class="retry-btn">إعادة المحاولة</button>
            </div>
        `;
    }
}

// تهيئة الإعدادات
function initSettings() {
    loadSettings();
    
    if (themeToggle) themeToggle.addEventListener('change', toggleTheme);
    if (fontSizeSelect) fontSizeSelect.addEventListener('change', changeFontSize);
    if (autoplayToggle) autoplayToggle.addEventListener('change', toggleAutoplay);
    if (clickEffectsToggle) clickEffectsToggle.addEventListener('change', toggleClickEffects);
}

// تحميل الإعدادات المحفوظة
function loadSettings() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light' && themeToggle) {
        document.body.classList.add('light-mode');
        themeToggle.checked = true;
    }
    
    const savedFontSize = localStorage.getItem('fontSize');
    if (savedFontSize && fontSizeSelect) {
        document.body.classList.remove('font-small', 'font-medium', 'font-large');
        document.body.classList.add(`font-${savedFontSize}`);
        fontSizeSelect.value = savedFontSize;
    }
    
    const savedAutoplay = localStorage.getItem('autoplay');
    if (savedAutoplay && autoplayToggle) autoplayToggle.checked = savedAutoplay === 'true';
    
    const savedClickEffects = localStorage.getItem('clickEffects');
    if (savedClickEffects !== null && clickEffectsToggle) clickEffectsToggle.checked = savedClickEffects === 'true';
    else if (clickEffectsToggle) clickEffectsToggle.checked = true;
}

// تبديل الوضع النهاري/الليلي
function toggleTheme() {
    if (themeToggle.checked) {
        document.body.classList.add('light-mode');
        localStorage.setItem('theme', 'light');
    } else {
        document.body.classList.remove('light-mode');
        localStorage.setItem('theme', 'dark');
    }
}

// تغيير حجم الخط
function changeFontSize() {
    const fontSize = fontSizeSelect.value;
    document.body.classList.remove('font-small', 'font-medium', 'font-large');
    document.body.classList.add(`font-${fontSize}`);
    localStorage.setItem('fontSize', fontSize);
}

// تبديل التشغيل التلقائي
function toggleAutoplay() {
    localStorage.setItem('autoplay', autoplayToggle.checked);
}

// تبديل تأثيرات النقر
function toggleClickEffects() {
    localStorage.setItem('clickEffects', clickEffectsToggle.checked);
}

// تهيئة الأحداث
function initEvents() {
    // أحداث الشريط السفلي
    if (homeBtn) homeBtn.addEventListener('click', goToHome);
    if (searchBottomBtn) searchBottomBtn.addEventListener('click', openSearchPopup);
    if (readingBtn) readingBtn.addEventListener('click', openReadingPopup);
    if (tafsirBtn) tafsirBtn.addEventListener('click', openTafsirPopup);
    
    // إغلاق البحث
    if (backBtn) backBtn.addEventListener('click', closeSearchPopup);
    
    // البحث أثناء الكتابة
    if (searchInput) {
        searchInput.addEventListener('input', (e) => searchVideos(e.target.value));
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') searchVideos(e.target.value);
        });
    }
    
    // إغلاق الشريط المصغر
    if (miniCloseArea) miniCloseArea.addEventListener('click', closeMiniPlayer);
    
    // فتح الفيديو من الشريط المصغر
    if (miniPlayer) {
        miniPlayer.addEventListener('click', (e) => {
            if (!e.target.closest('.mini-close-area')) openVideoPopup(currentVideoId);
        });
    }
    
    // إغلاق نوافذ القراءة والتفسير والإعدادات
    if (readingBackBtn) readingBackBtn.addEventListener('click', () => {
        if (currentSoraView === 'content') backToSowarList();
        else closeReadingPopup();
    });
    
    if (tafsirBackBtn) tafsirBackBtn.addEventListener('click', () => {
        if (currentTafsirView === 'content') backToTafsirList();
        else closeTafsirPopup();
    });
    
    if (settingsBackBtn) settingsBackBtn.addEventListener('click', closeSettingsPopup);
    
    // فتح الإعدادات
    if (settingsBtn) settingsBtn.addEventListener('click', openSettingsPopup);
    
    // البحث في السور
    if (soraSearchInput) soraSearchInput.addEventListener('input', (e) => searchSowar(e.target.value));
    
    // البحث في التفسير
    if (tafsirSearchInput) tafsirSearchInput.addEventListener('input', (e) => searchTafsir(e.target.value));
    
    // إدارة زر الرجوع في المتصفح
    window.addEventListener('popstate', (e) => {
        if (activePopup || (miniPlayer && miniPlayer.classList.contains('active'))) {
            handleBackButton();
            if (e.state) window.history.pushState(e.state, '');
        }
    });
    
    // التعامل مع تغيير حالة السجل التاريخي
    window.addEventListener('popstate', handlePopState);
    
    // إغلاق النوافذ بالضغط على زر Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') handleBackButton();
    });
    
    // تهيئة السحب للشريط المصغر
    initMiniPlayerDrag();
}

// تهيئة التطبيق
function initApp() {
    initEvents();
    initSettings();
    loadVideos();
    loadSowar();
    loadTafsir();
    window.history.replaceState({ main: true }, '');
}

// بدء التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initApp);

// منع القائمة عند الضغط بزر يمين الفأرة
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});

// منع F5 و Ctrl+R
document.addEventListener("keydown", function (e) {
    if (e.key === "F5" || (e.ctrlKey && e.key.toLowerCase() === "r")) {
        e.preventDefault();
    }
});

let lastY = 0;
document.addEventListener('touchmove', function(e) {
    const currentY = e.touches[0].clientY;
    if (window.scrollY === 0 && currentY > lastY) e.preventDefault();
    lastY = currentY;
}, { passive: false });

// تأثيرات النقر
(() => {
    const SOUND_URL = "https://assets.mixkit.co/sfx/preview/mixkit-interface-click-1126.mp3";
    const clickAudio = new Audio(SOUND_URL);
    clickAudio.preload = "auto";
    clickAudio.crossOrigin = "anonymous";
    clickAudio.volume = 0.9;

    function playClickSound() {
        try {
            const clickEffectsEnabled = localStorage.getItem('clickEffects') !== 'false';
            if (!clickEffectsEnabled) return;
            
            clickAudio.currentTime = 0;
            const p = clickAudio.play();
            if (p !== undefined) p.catch(() => {});
        } catch (e) {}
    }

    function isClickableElement(el) {
        if (!el) return false;
        const tag = el.tagName && el.tagName.toLowerCase();
        if (["button", "a", "input", "select", "textarea", "label"].includes(tag)) return true;
        if (el.getAttribute && (el.getAttribute("onclick") || el.getAttribute("role") === "button" || el.hasAttribute("data-clickable"))) return true;
        if (el.hasAttribute && el.hasAttribute("tabindex") && el.getAttribute("tabindex") !== "-1") return true;

        try {
            const style = window.getComputedStyle(el);
            if (style && style.cursor && style.cursor.includes("pointer")) return true;
        } catch (e) {}

        return false;
    }

    function onPointerDown(e) {
        const clickEffectsEnabled = localStorage.getItem('clickEffects') !== 'false';
        
        if (clickEffectsEnabled) {
            let ripple = document.createElement("span");
            ripple.classList.add("ripple");
            ripple.style.left = e.clientX + "px";
            ripple.style.top = e.clientY + "px";
            document.body.appendChild(ripple);
            setTimeout(() => ripple.remove(), 500);
        }
        
        let target = e.target;
        let found = null;
        for (let i = 0; i < 6 && target; i++) {
            if (isClickableElement(target)) { found = target; break; }
            target = target.parentElement;
        }

        if (!found && (typeof e.target.onclick === "function")) found = e.target;
        if (found) playClickSound();
    }

    document.addEventListener("pointerdown", onPointerDown, {passive: true});
    document.addEventListener("touchstart", onPointerDown, {passive: true});
    document.addEventListener("click", onPointerDown, {passive: true});
})();