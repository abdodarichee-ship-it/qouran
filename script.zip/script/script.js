// العناصر الرئيسية في DOM
const videosContainer = document.getElementById('videosContainer');
const videoPopup = document.getElementById('videoPopup');
const videoPlayer = document.getElementById('videoPlayer');
const videoTitle = document.getElementById('videoTitle');
const playlistContainer = document.getElementById('playlistContainer');
const miniPlayer = document.getElementById('miniPlayer');
const miniThumbnail = document.getElementById('miniThumbnail');
const miniTitle = document.getElementById('miniTitle');
const miniCloseArea = document.querySelector('.mini-close-area');
const searchPopup = document.getElementById('searchPopup');
const backBtn = document.getElementById('backBtn');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const loading = document.getElementById('loading');
const readingPopup = document.getElementById('readingPopup');
const readingBackBtn = document.getElementById('readingBackBtn');
const tafsirPopup = document.getElementById('tafsirPopup');
const tafsirBackBtn = document.getElementById('tafsirBackBtn');
const settingsPopup = document.getElementById('settingsPopup');
const settingsBackBtn = document.getElementById('settingsBackBtn');
const settingsBtn = document.getElementById('settingsBtn');

// عناصر القراءة
const sowarList = document.getElementById("sowarList");
const readingTitle = document.getElementById("readingTitle");
const readingText = document.getElementById("readingText");
const soraSearchInput = document.getElementById("soraSearchInput");
const soraContent = document.getElementById("soraContent");

// عناصر الإعدادات
const themeToggle = document.getElementById('themeToggle');
const fontSizeSelect = document.getElementById('fontSize');
const autoplayToggle = document.getElementById('autoplayToggle');
const videoQualitySelect = document.getElementById('videoQuality');
const notificationsToggle = document.getElementById('notificationsToggle');
const clickEffectsToggle = document.getElementById('clickEffectsToggle');

// أزرار الشريط السفلي
const homeBtn = document.getElementById('homeBtn');
const searchBottomBtn = document.getElementById('searchBottomBtn');
const readingBtn = document.getElementById('readingBtn');
const tafsirBtn = document.getElementById('tafsirBtn');

// المتغيرات العامة
let videosData = [];
let allSowar = [];
let currentVideoId = null;
let isVideoPlaying = false;
let startX = 0;
let currentX = 0;
let isDragging = false;
let activePopup = null;
let currentSoraView = 'list'; // 'list' أو 'content'

// دالة لإخفاء شريط التمرير
function hideScrollbar() {
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
}

// دالة لإظهار شريط التمرير
function showScrollbar() {
    document.body.style.overflow = '';
    document.documentElement.style.overflow = '';
}

// دالة لإخفاء جميع النوافذ
function hideAllPopups() {
    videoPopup.classList.remove('active');
    searchPopup.classList.remove('active');
    readingPopup.classList.remove('active');
    tafsirPopup.classList.remove('active');
    settingsPopup.classList.remove('active');
    activePopup = null;
    showScrollbar();
}

// دالة لتحديث حالة الأزرار في الشريط السفلي
function updateBottomBarButtons(activeButton) {
    // إزالة الفئة النشطة من جميع الأزرار
    homeBtn.classList.remove('active');
    searchBottomBtn.classList.remove('active');
    readingBtn.classList.remove('active');
    tafsirBtn.classList.remove('active');
    
    // إضافة الفئة النشطة للزر المحدد
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

// تحميل بيانات الفيديوهات من الملف الخارجي
async function loadVideos() {
    try {
        showLoading();
        
        // استدعاء البيانات الفعلية من الملف
        const response = await fetch('/vidou/vidou.html');
        
        if (!response.ok) {
            throw new Error(`فشل في تحميل البيانات: ${response.status}`);
        }
        
        const htmlText = await response.text();
        
        // تحويل النص إلى مستند HTML
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        // استخراج عناصر .qouran
        const qouranElements = doc.querySelectorAll('.qouran');
        
        if (qouranElements.length === 0) {
            throw new Error('لم يتم العثور على عناصر .qouran في الملف');
        }
        
        // تحويل كل عنصر .qouran إلى كائن فيديو
        videosData = Array.from(qouranElements).map((element, index) => {
            const imgElement = element.querySelector('img#photo');
            const titleElement = element.querySelector('h3#name');
            const codeElement = element.querySelector('samp#code');
            
            if (!imgElement || !titleElement || !codeElement) {
                console.warn(`عنصر .qouran غير مكتمل في الفهرس ${index}`);
                return null;
            }
            
            return {
                id: index + 1,
                title: titleElement.textContent.trim(),
                thumbnail: imgElement.src,
                videoCode: codeElement.textContent.trim()
            };
        }).filter(video => video !== null);
        
        if (videosData.length === 0) {
            throw new Error('لم يتم استخراج أي فيديوهات من الملف');
        }
        
        // عرض الفيديوهات في الصفحة الرئيسية
        renderVideos();
        
        hideLoading();
        
    } catch (error) {
        console.error('فشل في تحميل الفيديوهات:', error);
        hideLoading();
        showError(`فشل في تحميل الفيديوهات: ${error.message}`);
    }
}

// عرض الفيديوهات في الصفحة الرئيسية
function renderVideos() {
    videosContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="video-thumbnail">
            <div class="video-card-info">
                <h3 class="video-card-title">${video.title}</h3>
            </div>
        `;
        
        videoCard.addEventListener('click', () => openVideoPopup(video.id));
        videosContainer.appendChild(videoCard);
    });
}

// فتح نافذة الفيديو
function openVideoPopup(videoId) {
    const video = videosData.find(v => v.id === videoId);
    
    if (!video) return;
    
    currentVideoId = videoId;
    
    // تعيين الفيديو والعنوان
    const autoplay = localStorage.getItem('autoplay') === 'true' ? '1' : '0';
    videoPlayer.src = `https://www.youtube.com/embed/${video.videoCode}?autoplay=${autoplay}&enablejsapi=1`;
    videoTitle.textContent = video.title;
    
    // تعيين البيانات للشريط المصغر
    miniThumbnail.src = video.thumbnail;
    miniTitle.textContent = video.title;
    
    // عرض قائمة التشغيل
    renderPlaylist();
    
    // إخفاء جميع النوافذ الأخرى
    hideAllPopups();
    
    // فتح النافذة المنبثقة وإخفاء شريط التمرير
    videoPopup.classList.add('active');
    activePopup = videoPopup;
    miniPlayer.classList.remove('active');
    hideScrollbar();
    
    isVideoPlaying = true;
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(null);
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true, type: 'video' }, '');
}

// عرض قائمة الفيديوهات في النافذة المنبثقة
function renderPlaylist() {
    playlistContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const playlistItem = document.createElement('div');
        playlistItem.className = `playlist-item ${video.id === currentVideoId ? 'active' : ''}`;
        playlistItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="playlist-thumbnail">
            <div class="playlist-title">${video.title}</div>
        `;
        
        playlistItem.addEventListener('click', () => {
            if (video.id !== currentVideoId) {
                openVideoPopup(video.id);
            }
        });
        
        playlistContainer.appendChild(playlistItem);
    });
}

// إغلاق نافذة الفيديو
function closeVideoPopup() {
    videoPopup.classList.remove('active');
    activePopup = null;
    videoPlayer.src = '';
    miniPlayer.classList.remove('active');
    isVideoPlaying = false;
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// عرض الشريط المصغر
function showMiniPlayer() {
    videoPopup.classList.remove('active');
    activePopup = null;
    miniPlayer.classList.add('active');
    isVideoPlaying = true;
    
    // إظهار شريط التمرير عند التصغير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// إغلاق الشريط المصغر
function closeMiniPlayer() {
    miniPlayer.classList.remove('active');
    videoPlayer.src = '';
    isVideoPlaying = false;
    
    // التأكد من إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
}

// فتح نافذة البحث
function openSearchPopup() {
    // إخفاء جميع النوافذ الأخرى
    hideAllPopups();
    
    // فتح نافذة البحث
    searchPopup.classList.add('active');
    activePopup = searchPopup;
    searchInput.focus();
    
    // إخفاء شريط التمرير
    hideScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(searchBottomBtn);
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true, type: 'search' }, '');
}

// إغلاق نافذة البحث
function closeSearchPopup() {
    searchPopup.classList.remove('active');
    activePopup = null;
    searchInput.value = '';
    searchResults.innerHTML = '';
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// البحث عن الفيديوهات
function searchVideos(query) {
    searchResults.innerHTML = '';
    
    if (!query.trim()) {
        searchResults.innerHTML = '<div class="no-results">اكتب كلمة للبحث</div>';
        return;
    }
    
    const filteredVideos = videosData.filter(video => 
        video.title.toLowerCase().includes(query.toLowerCase())
    );
    
    if (filteredVideos.length === 0) {
        searchResults.innerHTML = '<div class="no-results">لا توجد نتائج للبحث</div>';
        return;
    }
    
    filteredVideos.forEach(video => {
        const searchItem = document.createElement('div');
        searchItem.className = 'search-result-item';
        searchItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="search-result-thumbnail">
            <div class="search-result-title">${video.title}</div>
        `;
        
        searchItem.addEventListener('click', () => {
            // إغلاق نافذة البحث أولاً
            closeSearchPopup();
            
            // ثم فتح الفيديو بعد تأخير بسيط لضمان إغلاق البحث أولاً
            setTimeout(() => {
                openVideoPopup(video.id);
            }, 100);
        });
        
        searchResults.appendChild(searchItem);
    });
}

// فتح نافذة القراءة
function openReadingPopup() {
    // إخفاء جميع النوافذ الأخرى
    hideAllPopups();
    
    // إعادة تعيين عرض القراءة إلى قائمة السور
    resetReadingView();
    
    // فتح نافذة القراءة
    readingPopup.classList.add('active');
    activePopup = readingPopup;
    
    // إخفاء شريط التمرير
    hideScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(readingBtn);
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true, type: 'reading', view: 'list' }, '');
}

// إعادة تعيين عرض القراءة إلى قائمة السور
function resetReadingView() {
    currentSoraView = 'list';
    sowarList.style.display = 'grid';
    soraContent.classList.remove('active');
    soraSearchInput.value = '';
    renderSowar(allSowar);
}

// إغلاق نافذة القراءة
function closeReadingPopup() {
    readingPopup.classList.remove('active');
    activePopup = null;
    
    // إعادة تعيين عرض القراءة
    resetReadingView();
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// العودة إلى قائمة السور من محتوى السورة
function backToSowarList() {
    currentSoraView = 'list';
    sowarList.style.display = 'grid';
    soraContent.classList.remove('active');
    
    // تحديث حالة السجل التاريخي
    if (activePopup === readingPopup) {
        window.history.replaceState({ popupOpen: true, type: 'reading', view: 'list' }, '');
    }
}

// فتح نافذة التفسير
function openTafsirPopup() {
    // إخفاء جميع النوافذ الأخرى
    hideAllPopups();
    
    // فتح نافذة التفسير
    tafsirPopup.classList.add('active');
    activePopup = tafsirPopup;
    
    // إخفاء شريط التمرير
    hideScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(tafsirBtn);
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true, type: 'tafsir' }, '');
}

// إغلاق نافذة التفسير
function closeTafsirPopup() {
    tafsirPopup.classList.remove('active');
    activePopup = null;
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// فتح نافذة الإعدادات
function openSettingsPopup() {
    // إخفاء جميع النوافذ الأخرى
    hideAllPopups();
    
    // فتح نافذة الإعدادات
    settingsPopup.classList.add('active');
    activePopup = settingsPopup;
    
    // إخفاء شريط التمرير
    hideScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(null);
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true, type: 'settings' }, '');
}

// إغلاق نافذة الإعدادات
function closeSettingsPopup() {
    settingsPopup.classList.remove('active');
    activePopup = null;
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // تحديث الشريط السفلي
    updateBottomBarButtons(homeBtn);
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// العودة إلى الصفحة الرئيسية
function goToHome() {
    // إذا كان هناك فيديو يعمل، عرض الشريط المصغر
    if (isVideoPlaying && videoPopup.classList.contains('active')) {
        showMiniPlayer();
    } else {
        // إخفاء جميع النوافذ
        hideAllPopups();
        closeMiniPlayer();
        
        // تحديث الشريط السفلي
        updateBottomBarButtons(homeBtn);
        
        // إزالة حالة من السجل التاريخي
        window.history.back();
    }
}

// إدارة زر الرجوع في المتصفح
function handleBackButton() {
    if (activePopup) {
        if (activePopup === searchPopup) {
            closeSearchPopup();
        } else if (activePopup === videoPopup) {
            showMiniPlayer();
        } else if (activePopup === readingPopup) {
            if (currentSoraView === 'content') {
                // إذا كنا في محتوى سورة، نعود للقائمة
                backToSowarList();
            } else {
                // إذا كنا في قائمة السور، نغلق النافذة
                closeReadingPopup();
            }
        } else if (activePopup === tafsirPopup) {
            closeTafsirPopup();
        } else if (activePopup === settingsPopup) {
            closeSettingsPopup();
        }
    } else if (miniPlayer.classList.contains('active')) {
        closeMiniPlayer();
    } else {
        // إذا لم يكن هناك نوافذ مفتوحة، العودة للصفحة الرئيسية
        updateBottomBarButtons(homeBtn);
    }
}

// تهيئة السحب لإغلاق الشريط المصغر
function initMiniPlayerDrag() {
    miniPlayer.addEventListener('touchstart', handleTouchStart);
    miniPlayer.addEventListener('touchmove', handleTouchMove);
    miniPlayer.addEventListener('touchend', handleTouchEnd);
    
    // لدعم الفأرة أيضاً
    miniPlayer.addEventListener('mousedown', handleMouseStart);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseEnd);
}

function handleTouchStart(e) {
    startX = e.touches[0].clientX;
    isDragging = true;
}

function handleTouchMove(e) {
    if (!isDragging) return;
    
    currentX = e.touches[0].clientX;
    const diff = currentX - startX;
    
    if (diff > 50) { // سحب لليمين
        miniPlayer.style.transform = `translateX(${diff}px)`;
    }
}

function handleTouchEnd() {
    if (!isDragging) return;
    
    isDragging = false;
    const diff = currentX - startX;
    
    if (diff > 100) { // إذا تم السحب لليمين بما يكفي
        closeMiniPlayer();
    } else {
        miniPlayer.style.transform = 'translateX(0)';
    }
    
    // إعادة تعيين القيم
    startX = 0;
    currentX = 0;
}

function handleMouseStart(e) {
    startX = e.clientX;
    isDragging = true;
    e.preventDefault();
}

function handleMouseMove(e) {
    if (!isDragging) return;
    
    currentX = e.clientX;
    const diff = currentX - startX;
    
    if (diff > 50) { // سحب لليمين
        miniPlayer.style.transform = `translateX(${diff}px)`;
    }
}

function handleMouseEnd() {
    if (!isDragging) return;
    
    isDragging = false;
    const diff = currentX - startX;
    
    if (diff > 100) { // إذا تم السحب لليمين بما يكفي
        closeMiniPlayer();
    } else {
        miniPlayer.style.transform = 'translateX(0)';
    }
    
    // إعادة تعيين القيم
    startX = 0;
    currentX = 0;
}

// عرض التحميل
function showLoading() {
    loading.style.display = 'flex';
    // إخفاء شريط التمرير أثناء التحميل
    hideScrollbar();
}

// إخفاء التحميل
function hideLoading() {
    loading.style.display = 'none';
    // إظهار شريط التمرير بعد انتهاء التحميل
    showScrollbar();
}

// عرض خطأ
function showError(message) {
    videosContainer.innerHTML = `
        <div class="error-message">
            <i class="fas fa-exclamation-triangle"></i>
            <p>${message}</p>
            <button onclick="loadVideos()" class="retry-btn">إعادة المحاولة</button>
        </div>
    `;
}

// تهيئة الإعدادات
function initSettings() {
    // تحميل الإعدادات المحفوظة
    loadSettings();
    
    // إضافة مستمعي الأحداث لعناصر الإعدادات
    themeToggle.addEventListener('change', toggleTheme);
    fontSizeSelect.addEventListener('change', changeFontSize);
    autoplayToggle.addEventListener('change', toggleAutoplay);
    videoQualitySelect.addEventListener('change', changeVideoQuality);
    notificationsToggle.addEventListener('change', toggleNotifications);
    clickEffectsToggle.addEventListener('change', toggleClickEffects);
}

// تحميل الإعدادات المحفوظة
function loadSettings() {
    // تحميل وضع المظهر
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
        themeToggle.checked = true;
    }
    
    // تحميل حجم الخط
    const savedFontSize = localStorage.getItem('fontSize');
    if (savedFontSize) {
        document.body.classList.remove('font-small', 'font-medium', 'font-large');
        document.body.classList.add(`font-${savedFontSize}`);
        fontSizeSelect.value = savedFontSize;
    }
    
    // تحميل إعداد التشغيل التلقائي
    const savedAutoplay = localStorage.getItem('autoplay');
    if (savedAutoplay) {
        autoplayToggle.checked = savedAutoplay === 'true';
    }
    
    // تحميل إعداد جودة الفيديو
    const savedVideoQuality = localStorage.getItem('videoQuality');
    if (savedVideoQuality) {
        videoQualitySelect.value = savedVideoQuality;
    }
    
    // تحميل إعداد الإشعارات
    const savedNotifications = localStorage.getItem('notifications');
    if (savedNotifications) {
        notificationsToggle.checked = savedNotifications === 'true';
    }
    
    // تحميل إعداد تأثيرات النقر
    const savedClickEffects = localStorage.getItem('clickEffects');
    if (savedClickEffects !== null) {
        clickEffectsToggle.checked = savedClickEffects === 'true';
    } else {
        // القيمة الافتراضية
        clickEffectsToggle.checked = true;
    }
}

// تبديل الوضع النهاري/الليلي
function toggleTheme() {
    if (themeToggle.checked) {
        document.body.classList.add('light-mode');
        localStorage.setItem('theme', 'light');
    } else {
        document.body.classList.remove('light-mode');
        localStorage.setItem('theme', 'dark');
    }
}

// تغيير حجم الخط
function changeFontSize() {
    const fontSize = fontSizeSelect.value;
    document.body.classList.remove('font-small', 'font-medium', 'font-large');
    document.body.classList.add(`font-${fontSize}`);
    localStorage.setItem('fontSize', fontSize);
}

// تبديل التشغيل التلقائي
function toggleAutoplay() {
    localStorage.setItem('autoplay', autoplayToggle.checked);
}

// تغيير جودة الفيديو
function changeVideoQuality() {
    localStorage.setItem('videoQuality', videoQualitySelect.value);
}

// تبديل الإشعارات
function toggleNotifications() {
    localStorage.setItem('notifications', notificationsToggle.checked);
}

// تبديل تأثيرات النقر
function toggleClickEffects() {
    localStorage.setItem('clickEffects', clickEffectsToggle.checked);
}

// تحميل السور من ملف خارجي
async function loadSowar() {
    try {
        const response = await fetch('/elkitab/elkitab.html');
        
        if (!response.ok) {
            throw new Error(`فشل في تحميل السور: ${response.status}`);
        }
        
        const htmlText = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        // استخراج السور
        allSowar = Array.from(doc.querySelectorAll('.sora'));
        
        // عرض السور
        renderSowar(allSowar);
        
    } catch (error) {
        console.error('فشل في تحميل السور:', error);
        sowarList.innerHTML = '<div class="error-message">فشل في تحميل السور</div>';
    }
}

// عرض السور في القائمة
function renderSowar(sowarListData) {
    sowarList.innerHTML = '';
    
    sowarListData.forEach(sora => {
        const nameElement = sora.querySelector('.name');
        const textElement = sora.querySelector('.text');
        
        if (!nameElement || !textElement) return;
        
        const name = nameElement.textContent.trim();
        const text = textElement.innerHTML;
        
        const soraItem = document.createElement('div');
        soraItem.className = 'sora-item';
        soraItem.innerHTML = `<h3>${name}</h3>`;
        
        soraItem.addEventListener('click', () => {
            openSora(name, text);
        });
        
        sowarList.appendChild(soraItem);
    });
}

// فتح سورة للقراءة
function openSora(name, text) {
    readingTitle.textContent = name;
    readingText.innerHTML = text;
    
    // إخفاء قائمة السور وإظهار محتوى السورة
    sowarList.style.display = 'none';
    soraContent.classList.add('active');
    currentSoraView = 'content';
    
    // تحديث حالة السجل التاريخي
    if (activePopup === readingPopup) {
        window.history.pushState({ popupOpen: true, type: 'reading', view: 'content', sora: name }, '');
    }
}

// البحث في السور
function searchSowar(query) {
    if (!query.trim()) {
        renderSowar(allSowar);
        return;
    }
    
    const filteredSowar = allSowar.filter(sora => {
        const nameElement = sora.querySelector('.name');
        return nameElement && nameElement.textContent.toLowerCase().includes(query.toLowerCase());
    });
    
    renderSowar(filteredSowar);
}

// التعامل مع تغيير حالة السجل التاريخي
function handlePopState(event) {
    if (event.state) {
        if (event.state.popupOpen) {
            if (event.state.type === 'reading') {
                if (event.state.view === 'list') {
                    // العودة إلى قائمة السور
                    backToSowarList();
                } else if (event.state.view === 'content') {
                    // البقاء في محتوى السورة (لا تفعل شيئاً)
                    // أو يمكنك إعادة تحميل السورة إذا لزم الأمر
                }
            }
        } else {
            // العودة للصفحة الرئيسية
            hideAllPopups();
            closeMiniPlayer();
            updateBottomBarButtons(homeBtn);
        }
    }
}

// تهيئة الأحداث
function initEvents() {
    // أحداث الشريط السفلي
    homeBtn.addEventListener('click', goToHome);
    searchBottomBtn.addEventListener('click', openSearchPopup);
    readingBtn.addEventListener('click', openReadingPopup);
    tafsirBtn.addEventListener('click', openTafsirPopup);
    
    // إغلاق البحث
    backBtn.addEventListener('click', closeSearchPopup);
    
    // البحث أثناء الكتابة
    searchInput.addEventListener('input', (e) => {
        searchVideos(e.target.value);
    });
    
    // إغلاق البحث بالضغط على زر الإدخال
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchVideos(e.target.value);
        }
    });
    
    // إغلاق الشريط المصغر
    miniCloseArea.addEventListener('click', closeMiniPlayer);
    
    // فتح الفيديو من الشريط المصغر
    miniPlayer.addEventListener('click', (e) => {
        if (!e.target.closest('.mini-close-area')) {
            openVideoPopup(currentVideoId);
        }
    });
    
    // إغلاق نوافذ القراءة والتفسير والإعدادات
    readingBackBtn.addEventListener('click', () => {
        if (currentSoraView === 'content') {
            // إذا كنا في محتوى سورة، نعود للقائمة
            backToSowarList();
        } else {
            // إذا كنا في قائمة السور، نغلق النافذة
            closeReadingPopup();
        }
    });
    
    tafsirBackBtn.addEventListener('click', closeTafsirPopup);
    settingsBackBtn.addEventListener('click', closeSettingsPopup);
    
    // فتح الإعدادات
    settingsBtn.addEventListener('click', openSettingsPopup);
    
    // البحث في السور
    soraSearchInput.addEventListener('input', (e) => {
        searchSowar(e.target.value);
    });
    
    // إدارة زر الرجوع في المتصفح
    window.addEventListener('popstate', (e) => {
        // منع السلوك الافتراضي للرجوع
        if (activePopup || miniPlayer.classList.contains('active')) {
            handleBackButton();
            // منع الانتقال للصفحة السابقة
            if (e.state) {
                window.history.pushState(e.state, '');
            }
        }
    });
    
    // التعامل مع تغيير حالة السجل التاريخي
    window.addEventListener('popstate', handlePopState);
    
    // إغلاق النوافذ بالضغط على زر Escape (للأجهزة التي تدعمه)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            handleBackButton();
        }
    });
    
    // تهيئة السحب للشريط المصغر
    initMiniPlayerDrag();
}

// تهيئة التطبيق
function initApp() {
    initEvents();
    initSettings();
    loadVideos();
    loadSowar();
    
    // تهيئة حالة البداية في السجل التاريخي
    window.history.replaceState({ main: true }, '');
}

// بدء التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initApp);

// منع القائمة عند الضغط بزر يمين الفأرة
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});

// منع F5 و Ctrl+R
document.addEventListener("keydown", function (e) {
    // منع F5
    if (e.key === "F5") {
        e.preventDefault();
    }

    // منع Ctrl + R
    if (e.ctrlKey && e.key.toLowerCase() === "r") {
        e.preventDefault();
    }
});

let lastY = 0;

document.addEventListener('touchmove', function(e) {
    const currentY = e.touches[0].clientY;

    // إذا المستخدم يسحب الصفحة لأسفل من الأعلى → نمنع الحركة التي تسبب ريفريش
    if (window.scrollY === 0 && currentY > lastY) {
        e.preventDefault();
    }

    lastY = currentY;
}, { passive: false });

document.addEventListener("click", (e) => {
    // التحقق من إعداد تأثيرات النقر
    const clickEffectsEnabled = localStorage.getItem('clickEffects') !== 'false';
    
    if (clickEffectsEnabled) {
        const sound = document.getElementById("clickSound");
        sound.currentTime = 0;
        sound.play();
        
        let ripple = document.createElement("span");
        ripple.classList.add("ripple");
        ripple.style.left = e.clientX + "px";
        ripple.style.top = e.clientY + "px";

        document.body.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 500);
    }
});