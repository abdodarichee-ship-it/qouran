// العناصر الرئيسية في DOM
const videosContainer = document.getElementById('videosContainer');
const videoPopup = document.getElementById('videoPopup');
const videoPlayer = document.getElementById('videoPlayer');
const videoTitle = document.getElementById('videoTitle');
const playlistContainer = document.getElementById('playlistContainer');
const miniPlayer = document.getElementById('miniPlayer');
const miniThumbnail = document.getElementById('miniThumbnail');
const miniTitle = document.getElementById('miniTitle');
const miniCloseArea = document.querySelector('.mini-close-area');
const searchIcon = document.querySelector('.search-icon');
const searchPopup = document.getElementById('searchPopup');
const backBtn = document.getElementById('backBtn');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const loading = document.getElementById('loading');

// المتغيرات العامة
let videosData = [];
let currentVideoId = null;
let isVideoPlaying = false;
let startX = 0;
let currentX = 0;
let isDragging = false;

// دالة لإخفاء شريط التمرير
function hideScrollbar() {
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
}

// دالة لإظهار شريط التمرير
function showScrollbar() {
    document.body.style.overflow = '';
    document.documentElement.style.overflow = '';
}

// تحميل بيانات الفيديوهات من الملف الخارجي
async function loadVideos() {
    try {
        showLoading();
        
        // استدعاء البيانات الفعلية من الملف
        const response = await fetch('/vidou/vidou.html');
        
        if (!response.ok) {
            throw new Error(`فشل في تحميل البيانات: ${response.status}`);
        }
        
        const htmlText = await response.text();
        
        // تحويل النص إلى مستند HTML
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, 'text/html');
        
        // استخراج عناصر .qouran
        const qouranElements = doc.querySelectorAll('.qouran');
        
        if (qouranElements.length === 0) {
            throw new Error('لم يتم العثور على عناصر .qouran في الملف');
        }
        
        // تحويل كل عنصر .qouran إلى كائن فيديو
        videosData = Array.from(qouranElements).map((element, index) => {
            const imgElement = element.querySelector('img#photo');
            const titleElement = element.querySelector('h3#name');
            const codeElement = element.querySelector('samp#code');
            
            if (!imgElement || !titleElement || !codeElement) {
                console.warn(`عنصر .qouran غير مكتمل في الفهرس ${index}`);
                return null;
            }
            
            return {
                id: index + 1,
                title: titleElement.textContent.trim(),
                thumbnail: imgElement.src,
                videoCode: codeElement.textContent.trim()
            };
        }).filter(video => video !== null);
        
        if (videosData.length === 0) {
            throw new Error('لم يتم استخراج أي فيديوهات من الملف');
        }
        
        // عرض الفيديوهات في الصفحة الرئيسية
        renderVideos();
        
        hideLoading();
        
    } catch (error) {
        console.error('فشل في تحميل الفيديوهات:', error);
        hideLoading();
        showError(`فشل في تحميل الفيديوهات: ${error.message}`);
    }
}

// عرض الفيديوهات في الصفحة الرئيسية
function renderVideos() {
    videosContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="video-thumbnail">
            <div class="video-card-info">
                <h3 class="video-card-title">${video.title}</h3>
            </div>
        `;
        
        videoCard.addEventListener('click', () => openVideoPopup(video.id));
        videosContainer.appendChild(videoCard);
    });
}

// فتح نافذة الفيديو
function openVideoPopup(videoId) {
    const video = videosData.find(v => v.id === videoId);
    
    if (!video) return;
    
    currentVideoId = videoId;
    
    // تعيين الفيديو والعنوان
    videoPlayer.src = `https://www.youtube.com/embed/${video.videoCode}?autoplay=1&enablejsapi=1`;
    videoTitle.textContent = video.title;
    
    // تعيين البيانات للشريط المصغر
    miniThumbnail.src = video.thumbnail;
    miniTitle.textContent = video.title;
    
    // عرض قائمة التشغيل
    renderPlaylist();
    
    // فتح النافذة المنبثقة وإخفاء شريط التمرير
    videoPopup.classList.add('active');
    miniPlayer.classList.remove('active');
    hideScrollbar();
    
    isVideoPlaying = true;
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ popupOpen: true }, '');
}

// عرض قائمة الفيديوهات في النافذة المنبثقة
function renderPlaylist() {
    playlistContainer.innerHTML = '';
    
    videosData.forEach(video => {
        const playlistItem = document.createElement('div');
        playlistItem.className = `playlist-item ${video.id === currentVideoId ? 'active' : ''}`;
        playlistItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="playlist-thumbnail">
            <div class="playlist-title">${video.title}</div>
        `;
        
        playlistItem.addEventListener('click', () => {
            if (video.id !== currentVideoId) {
                openVideoPopup(video.id);
            }
        });
        
        playlistContainer.appendChild(playlistItem);
    });
}

// إغلاق نافذة الفيديو
function closeVideoPopup() {
    videoPopup.classList.remove('active');
    videoPlayer.src = '';
    miniPlayer.classList.remove('active');
    isVideoPlaying = false;
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// عرض الشريط المصغر
function showMiniPlayer() {
    videoPopup.classList.remove('active');
    miniPlayer.classList.add('active');
    isVideoPlaying = true;
    
    // إظهار شريط التمرير عند التصغير
    showScrollbar();
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// إغلاق الشريط المصغر
function closeMiniPlayer() {
    miniPlayer.classList.remove('active');
    videoPlayer.src = '';
    isVideoPlaying = false;
    
    // التأكد من إظهار شريط التمرير
    showScrollbar();
}

// فتح نافذة البحث
function openSearchPopup() {
    searchPopup.classList.add('active');
    searchInput.focus();
    
    // إخفاء شريط التمرير
    hideScrollbar();
    
    // إضافة حالة إلى السجل التاريخي
    window.history.pushState({ searchOpen: true }, '');
}

// إغلاق نافذة البحث
function closeSearchPopup() {
    searchPopup.classList.remove('active');
    searchInput.value = '';
    searchResults.innerHTML = '';
    
    // إظهار شريط التمرير
    showScrollbar();
    
    // إزالة حالة من السجل التاريخي
    window.history.back();
}

// البحث عن الفيديوهات
function searchVideos(query) {
    searchResults.innerHTML = '';
    
    if (!query.trim()) {
        searchResults.innerHTML = '<div class="no-results">اكتب كلمة للبحث</div>';
        return;
    }
    
    const filteredVideos = videosData.filter(video => 
        video.title.toLowerCase().includes(query.toLowerCase())
    );
    
    if (filteredVideos.length === 0) {
        searchResults.innerHTML = '<div class="no-results">لا توجد نتائج للبحث</div>';
        return;
    }
    
    filteredVideos.forEach(video => {
        const searchItem = document.createElement('div');
        searchItem.className = 'search-result-item';
        searchItem.innerHTML = `
            <img src="${video.thumbnail}" alt="${video.title}" class="search-result-thumbnail">
            <div class="search-result-title">${video.title}</div>
        `;
        
        searchItem.addEventListener('click', () => {
            // إغلاق نافذة البحث أولاً
            closeSearchPopup();
            
            // ثم فتح الفيديو بعد تأخير بسيط لضمان إغلاق البحث أولاً
            setTimeout(() => {
                openVideoPopup(video.id);
            }, 100);
        });
        
        searchResults.appendChild(searchItem);
    });
}

// إدارة زر الرجوع في المتصفح
function handleBackButton() {
    if (searchPopup.classList.contains('active')) {
        closeSearchPopup();
    } else if (videoPopup.classList.contains('active')) {
        showMiniPlayer();
    } else if (miniPlayer.classList.contains('active')) {
        closeMiniPlayer();
    }
}

// تهيئة السحب لإغلاق الشريط المصغر
function initMiniPlayerDrag() {
    miniPlayer.addEventListener('touchstart', handleTouchStart);
    miniPlayer.addEventListener('touchmove', handleTouchMove);
    miniPlayer.addEventListener('touchend', handleTouchEnd);
    
    // لدعم الفأرة أيضاً
    miniPlayer.addEventListener('mousedown', handleMouseStart);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseEnd);
}

function handleTouchStart(e) {
    startX = e.touches[0].clientX;
    isDragging = true;
}

function handleTouchMove(e) {
    if (!isDragging) return;
    
    currentX = e.touches[0].clientX;
    const diff = currentX - startX;
    
    if (diff > 50) { // سحب لليمين
        miniPlayer.style.transform = `translateX(${diff}px)`;
    }
}

function handleTouchEnd() {
    if (!isDragging) return;
    
    isDragging = false;
    const diff = currentX - startX;
    
    if (diff > 100) { // إذا تم السحب لليمين بما يكفي
        closeMiniPlayer();
    } else {
        miniPlayer.style.transform = 'translateX(0)';
    }
    
    // إعادة تعيين القيم
    startX = 0;
    currentX = 0;
}

function handleMouseStart(e) {
    startX = e.clientX;
    isDragging = true;
    e.preventDefault();
}

function handleMouseMove(e) {
    if (!isDragging) return;
    
    currentX = e.clientX;
    const diff = currentX - startX;
    
    if (diff > 50) { // سحب لليمين
        miniPlayer.style.transform = `translateX(${diff}px)`;
    }
}

function handleMouseEnd() {
    if (!isDragging) return;
    
    isDragging = false;
    const diff = currentX - startX;
    
    if (diff > 100) { // إذا تم السحب لليمين بما يكفي
        closeMiniPlayer();
    } else {
        miniPlayer.style.transform = 'translateX(0)';
    }
    
    // إعادة تعيين القيم
    startX = 0;
    currentX = 0;
}

// عرض التحميل
function showLoading() {
    loading.style.display = 'flex';
    // إخفاء شريط التمرير أثناء التحميل
    hideScrollbar();
}

// إخفاء التحميل
function hideLoading() {
    loading.style.display = 'none';
    // إظهار شريط التمرير بعد انتهاء التحميل
    showScrollbar();
}

// عرض خطأ
function showError(message) {
    videosContainer.innerHTML = `
        <div class="error-message">
            <i class="fas fa-exclamation-triangle"></i>
            <p>${message}</p>
            <button onclick="loadVideos()" class="retry-btn">إعادة المحاولة</button>
        </div>
    `;
}

// تهيئة الأحداث
function initEvents() {
    // فتح البحث
    searchIcon.addEventListener('click', openSearchPopup);
    
    // إغلاق البحث
    backBtn.addEventListener('click', closeSearchPopup);
    
    // البحث أثناء الكتابة
    searchInput.addEventListener('input', (e) => {
        searchVideos(e.target.value);
    });
    
    // إغلاق البحث بالضغط على زر الإدخال
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchVideos(e.target.value);
        }
    });
    
    // إغلاق الشريط المصغر
    miniCloseArea.addEventListener('click', closeMiniPlayer);
    
    // فتح الفيديو من الشريط المصغر
    miniPlayer.addEventListener('click', (e) => {
        if (!e.target.closest('.mini-close-area')) {
            openVideoPopup(currentVideoId);
        }
    });
    
    // إدارة زر الرجوع في المتصفح
    window.addEventListener('popstate', (e) => {
        // منع السلوك الافتراضي للرجوع
        if (videoPopup.classList.contains('active') || 
            searchPopup.classList.contains('active') || 
            miniPlayer.classList.contains('active')) {
            handleBackButton();
            // منع الانتقال للصفحة السابقة
            if (e.state) {
                window.history.pushState(e.state, '');
            }
        }
    });
    
    // إغلاق النوافذ بالضغط على زر Escape (للأجهزة التي تدعمه)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            handleBackButton();
        }
    });
    
    // تهيئة السحب للشريط المصغر
    initMiniPlayerDrag();
}

// تهيئة التطبيق
function initApp() {
    initEvents();
    loadVideos();
    
    // تهيئة حالة البداية في السجل التاريخي
    window.history.replaceState({ main: true }, '');
}

// بدء التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initApp);



// منع القائمة عند الضغط بزر يمين الفأرة
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});

// منع F5 و Ctrl+R
document.addEventListener("keydown", function (e) {

    // منع F5
    if (e.key === "F5") {
        e.preventDefault();
    }

    // منع Ctrl + R
    if (e.ctrlKey && e.key.toLowerCase() === "r") {
        e.preventDefault();
    }
});


let lastY = 0;

document.addEventListener('touchmove', function(e) {
    const currentY = e.touches[0].clientY;

    // إذا المستخدم يسحب الصفحة لأسفل من الأعلى → نمنع الحركة التي تسبب ريفريش
    if (window.scrollY === 0 && currentY > lastY) {
        e.preventDefault();
    }

    lastY = currentY;
}, { passive: false });