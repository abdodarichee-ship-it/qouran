        document.addEventListener('DOMContentLoaded', function() {
            // العناصر الرئيسية
            const videosGrid = document.getElementById('videosGrid');
            const videoModal = document.getElementById('videoModal');
            const searchInput = document.getElementById('searchInput');
            const breakModal = document.getElementById('breakModal');
            
            // عناصر مشغل الفيديو لسطح المكتب
            const desktopVideoPlayer = document.getElementById('desktopVideoPlayer');
            const desktopVideoTitle = document.getElementById('desktopVideoTitle');
            const desktopPlaylist = document.getElementById('desktopPlaylist');
            
            // عناصر مشغل الفيديو للهاتف
            const mobileVideoPlayer = document.getElementById('mobileVideoPlayer');
            const mobileVideoTitle = document.getElementById('mobileVideoTitle');
            const mobilePlaylist = document.getElementById('mobilePlaylist');
            
            // بيانات الفيديوهات
            const videoData = [];
            
            // جلب بيانات الفيديوهات من الملف الخارجي
            fetch('/vidou/vidou.html')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    // إنشاء عنصر مؤقت لتحليل HTML
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(data, 'text/html');
                    
                    // استخراج بيانات الفيديوهات
                    const videoElements = doc.querySelectorAll('.vidqouran .qouran');
                    
                    videoElements.forEach(video => {
                        const img = video.querySelector('#photo');
                        const name = video.querySelector('#name');
                        const code = video.querySelector('#code');
                        
                        if (img && name && code) {
                            videoData.push({
                                thumbnail: img.src,
                                title: name.textContent,
                                code: code.textContent
                            });
                        }
                    });
                    
                    // عرض الفيديوهات بعد جلب البيانات
                    displayVideos(videoData);
                })
                .catch(error => {
                    console.error('Error fetching video data:', error);
                    // استخدام بيانات افتراضية في حالة فشل الجلب
                    loadDefaultData();
                });
            
            // تحميل بيانات افتراضية في حالة فشل جلب البيانات
            function loadDefaultData() {
                const defaultData = [
                    {
                        thumbnail: "https://i.ytimg.com/vi/djfdfj2d3/maxresdefault.jpg",
                        title: "سورة الفاتحة",
                        code: "djfdfj2d3"
                    },
                    {
                        thumbnail: "https://i.ytimg.com/vi/abc123def/maxresdefault.jpg",
                        title: "سورة البقرة",
                        code: "abc123def"
                    },
                    {
                        thumbnail: "https://i.ytimg.com/vi/xyz789ghi/maxresdefault.jpg",
                        title: "سورة آل عمران",
                        code: "xyz789ghi"
                    },
                    {
                        thumbnail: "https://i.ytimg.com/vi/jkl012mno/maxresdefault.jpg",
                        title: "سورة النساء",
                        code: "jkl012mno"
                    },
                    {
                        thumbnail: "https://i.ytimg.com/vi/pqr345stu/maxresdefault.jpg",
                        title: "سورة المائدة",
                        code: "pqr345stu"
                    },
                    {
                        thumbnail: "https://i.ytimg.com/vi/vwx678yz/maxresdefault.jpg",
                        title: "سورة الأنعام",
                        code: "vwx678yz"
                    }
                ];
                
                videoData.push(...defaultData);
                displayVideos(videoData);
            }
            
            // المتغيرات الحالية
            let currentVideo = null;
            
            // عرض الفيديوهات في الشبكة الرئيسية
            function displayVideos(videos) {
                videosGrid.innerHTML = '';
                
                videos.forEach(video => {
                    const card = document.createElement('div');
                    card.className = 'video-card';
                    card.innerHTML = `
                        <img class="video-thumbnail" src="${video.thumbnail}" alt="${video.title}">
                        <div class="video-info">
                            <div class="video-title">${video.title}</div>
                        </div>
                    `;
                    
                    card.addEventListener('click', () => {
                        openVideoModal(video);
                    });
                    
                    videosGrid.appendChild(card);
                });
            }
            
            // فتح اللافتة المنبثقة للفيديو
            function openVideoModal(video) {
                currentVideo = video;
                
                // تحديث العنوان والفيديو في كلا الوضعين
                desktopVideoTitle.textContent = video.title;
                mobileVideoTitle.textContent = video.title;
                desktopVideoPlayer.src = `https://www.youtube.com/embed/${video.code}?autoplay=1&rel=0&modestbranding=1`;
                mobileVideoPlayer.src = `https://www.youtube.com/embed/${video.code}?autoplay=1&rel=0&modestbranding=1`;
                
                // إظهار اللافتة وإخفاء شريط التمرير
                videoModal.classList.add('active');
                document.body.classList.add('modal-open');
                
                // تحديث حالة المتصفح
                history.pushState({ modalOpen: true }, '', `#${video.code}`);
                
                // إنشاء قائمة التشغيل
                createPlaylist();
                
                // إعادة تعيين مؤقت الراحة
                resetBreakTimer();
            }
            
            // إنشاء قائمة التشغيل
            function createPlaylist() {
                desktopPlaylist.innerHTML = '';
                mobilePlaylist.innerHTML = '';
                
                videoData.forEach(video => {
                    // إنشاء بطاقة لقائمة سطح المكتب
                    const desktopCard = document.createElement('div');
                    desktopCard.className = `playlist-video-card ${video.code === currentVideo.code ? 'active' : ''}`;
                    desktopCard.innerHTML = `
                        <img class="playlist-thumbnail" src="${video.thumbnail}" alt="${video.title}">
                        <div class="playlist-video-title">${video.title}</div>
                    `;
                    
                    desktopCard.addEventListener('click', () => {
                        switchVideo(video);
                    });
                    
                    desktopPlaylist.appendChild(desktopCard);
                    
                    // إنشاء بطاقة لقائمة الهاتف
                    const mobileCard = document.createElement('div');
                    mobileCard.className = `mobile-playlist-video-card ${video.code === currentVideo.code ? 'active' : ''}`;
                    mobileCard.innerHTML = `
                        <img class="mobile-playlist-thumbnail" src="${video.thumbnail}" alt="${video.title}">
                        <div class="mobile-playlist-video-title">${video.title}</div>
                    `;
                    
                    mobileCard.addEventListener('click', () => {
                        switchVideo(video);
                    });
                    
                    mobilePlaylist.appendChild(mobileCard);
                });
            }
            
            // تغيير الفيديو داخل اللافتة
            function switchVideo(video) {
                currentVideo = video;
                
                // تحديث العنوان والفيديو في كلا الوضعين
                desktopVideoTitle.textContent = video.title;
                mobileVideoTitle.textContent = video.title;
                desktopVideoPlayer.src = `https://www.youtube.com/embed/${video.code}?autoplay=1&rel=0&modestbranding=1`;
                mobileVideoPlayer.src = `https://www.youtube.com/embed/${video.code}?autoplay=1&rel=0&modestbranding=1`;
                
                // تحديث حالة المتصفح
                history.replaceState({ modalOpen: true }, '', `#${video.code}`);
                
                // تحديث القائمة النشطة
                createPlaylist();
                
                // إعادة تعيين مؤقت الراحة
                resetBreakTimer();
            }
            
            // إغلاق اللافتة المنبثقة
            function closeVideoModal() {
                videoModal.classList.remove('active');
                document.body.classList.remove('modal-open');
                desktopVideoPlayer.src = '';
                mobileVideoPlayer.src = '';
                
                // تحديث حالة المتصفح
                if (history.state && history.state.modalOpen) {
                    history.back();
                }
            }
            
            // البحث عن الفيديوهات
            function searchVideos(query) {
                const filteredVideos = videoData.filter(video => 
                    video.title.toLowerCase().includes(query.toLowerCase())
                );
                displayVideos(filteredVideos);
            }
            
            // التحكم في زر الرجوع في المتصفح - بدون تأخير
            window.addEventListener('popstate', function(event) {
                if (videoModal.classList.contains('active')) {
                    closeVideoModal();
                }
            });
            
            // إعداد مؤقت وقت الراحة (ساعتين)
            let breakTimer;
            function startBreakTimer() {
                // 7200000 مللي ثانية = ساعتين
                breakTimer = setTimeout(() => {
                    closeVideoModal();
                    breakModal.classList.add('active');
                }, 7200000); // للتجربة، يمكنك تغييرها إلى 10000 (10 ثواني)
            }
            
            // إعادة تعيين المؤقت عند فتح فيديو جديد
            function resetBreakTimer() {
                clearTimeout(breakTimer);
                startBreakTimer();
            }
            
            // إعداد المستمعين للأحداث
            searchInput.addEventListener('input', function() {
                searchVideos(this.value);
            });
            
            breakModal.addEventListener('click', function() {
                breakModal.classList.remove('active');
            });
            
            // البدء بتعيين المؤقت
            startBreakTimer();
        });