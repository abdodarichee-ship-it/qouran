  // استدعاء محتوى الملف الخارجي /vidou/vidou.html
  fetch('/vidou/vidou.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('videos-container').innerHTML = data;

      // بعد إدخال المحتوى، يمكنك تنفيذ كود JS الخاص بعرض الفيديوهات أو أي تفاعلات
      console.log('تم تحميل الفيديوهات بنجاح');
    })
    .catch(error => console.error('حدث خطأ أثناء تحميل الملف:', error));